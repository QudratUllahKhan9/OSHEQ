import React from 'react';
import Header from '../components/Header/Header';
import Footer from '../components/Footer/Footer';
import AtpLogin from '../components/AtpLogin/AtpLogin';
export default function Atp() { return <><Header /><main><AtpLogin /></main><Footer /></>; }
